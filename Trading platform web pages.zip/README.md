
  # Trading platform web pages

  This is a code bundle for Trading platform web pages. The original project is available at https://www.figma.com/design/IJEuPA6PYWEmcAN93uf2SZ/Trading-platform-web-pages.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  